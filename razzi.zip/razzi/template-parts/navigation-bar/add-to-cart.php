<?php
/**
 * Template file for displaying filter mobile
 *
 * @package Razzi
 */


do_action( 'razzi_navigation_bar_before_atc_template' );

	do_action( 'razzi_navigation_bar_content_atc_template' );

do_action( 'razzi_navigation_bar_after_atc_template' );

?>