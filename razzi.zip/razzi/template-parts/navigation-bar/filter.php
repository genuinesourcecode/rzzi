<?php
/**
 * Template file for displaying filter mobile
 *
 * @package Razzi
 */
?>

<a href="#catalog-filters" class="rz-navigation-bar_icon filter-icon toggle-filters" data-toggle="modal" data-target="catalog-filters-modal">
	<?php echo \Razzi\Icon::get_svg( 'filter-2', '', 'mobile' ) ?>
</a>