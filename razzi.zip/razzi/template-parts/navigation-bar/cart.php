<?php
/**
 * Template file for displaying cart mobile
 *
 * @package Razzi
 */
?>

<a href="#" class="rz-navigation-bar_icon cart-icon" data-toggle="modal" data-target="cart-modal">
	<?php echo \Razzi\Icon::get_svg( 'cart', '', 'shop' ); ?>
</a>
