<?php
/**
 * Template part for display socials
 * @package Razzi
 */

?>
<div class="header-socials">
	<?php \Razzi\Helper::socials_menu(); ?>
</div><!-- .header-socials -->
